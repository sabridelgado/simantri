<div class="container-fluid">
<script>
    $(document).ready(function() {
      $('#import_form').on('submit', function(event) {
        event.preventDefault();
        $.ajax({
          url: "<?php echo base_url() ?>api/matakuliah_import",
          method: "POST",
          data: new FormData(this),
          contentType: false,
          cache: false,
          processData: false,
          success: function(data) {
            $('#file').val('');
            // alert(data);
            $("#importmatakuliahModal").modal('hide');
            window.location = "<?php echo site_url('matakuliah'); ?>";
          }
        })
      });

    });
  </script>
  <?php
  if ($this->session->flashdata('add')) {
    $message = $this->session->flashdata('add');
    $heading = '#Tambah matakuliah';
  } else if ($this->session->flashdata('update')) {
    $message = $this->session->flashdata('update');
    $heading = '#Update matakuliah';
  } else if ($this->session->flashdata('delete')) {
    $message = $this->session->flashdata('delete');
    $heading = '#Delete matakuliah';
  }else if ($this->session->flashdata('import')) {
    $message = $this->session->flashdata('import');
    $heading = '#import Matakuliah';
  }
  ?>
  <?php if (isset($message)) { ?>
    <script>
      $(document).ready(function() {
        $.toast({
          text: '<?php echo $message; ?>',
          heading: '<?php echo $heading; ?>',
          position: 'top-right',
          width: 'auto',
          showHideTransition: 'slide',
          icon: 'info',
          hideAfter: 5000
        })
      });
    </script>
  <?php } ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Data matakuliah</h1>
  <hr>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <a href="#" class="btn btn-primary btn-icon-split btn-sm" data-toggle="modal" data-target="#matakuliahModal">
        <span class="icon text-white-50">
          <i class="fas fa-plus"></i>
        </span>
        <span class="text">Tambah Data</span>
      </a>

      <!-- matakuliah Modal-->
      <div class="modal fade" id="matakuliahModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tambah matakuliah Baru</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <?php echo form_open_multipart("matakuliah/input") ?>
            <div class="modal-body">
              <div class="form-group">
                <label for=""><b>Id matakuliah</b></label>
                <input type="text" class="form-control" placeholder="Masukkan id matakuliah..." name="matakuliah_id" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Nama matakuliah</b></label>
                <input type="text" class="form-control" placeholder="Masukkan Nama matakuliah..." name="matakuliah_nama" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>SKS</b></label>
                <input type="text" class="form-control" placeholder="Masukkan SKS..." name="matakuliah_sks" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Semester</b></label>
                <input type="text" class="form-control" placeholder="Masukkan semester..." name="matakuliah_semester" required="required">
              </div>

            </div>
            <div class="modal-footer">
              <button class="btn btn-primary" type="submit">Tambah</button>
              <?php echo form_close(); ?>
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>

            </div>
          </div>
        </div>
      </div>
      
      <!-- Import Data Matakuliah Modal-->
      <div class="modal fade" id="importmatakuliahModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Import Data Matakuliah</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>

            <form method="post" id="import_form" enctype="multipart/form-data">
              <div class="modal-body">
                <div class="form-group">
                  <a href="<?php echo base_url("upload/excel/format_matakuliah.xlsx"); ?>">Download Format</a><br>
                  <label for=""><b>Import Data</b></label>
                  <input type="file" class="form-control" name="file" id="file" required accept=".xls, .xlsx">
                </div>

              </div>
              <div class="modal-footer">
                <input type="submit" name="import" value="Import" class="btn btn-primary" />
            </form>

            <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>

          </div>
        </div>
      </div>
    </div>

      <a href="<?php echo site_url('matakuliah') ?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-refresh"></i>
        </span>
        <span class="text">Refresh Halaman</span>
      </a>
    </div>

    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="width: 5%;">No</th>
              <th style="width: 12%;">#</th>
              <th>Id Matakuliah</th>
              <th>Nama Matakuliah</th>
              <th>SKS</th>
              <th>Semester</th>
            </tr>
          </thead>

          <tbody>
            <?php $no = 1;
            foreach ($matakuliah as $key) { ?>
              <tr>
                <td><?php echo $no; ?></td>
                <td>
                  <a href="#" class="btn btn-warning btn-icon-split btn-sm" data-toggle="modal" data-target="#matakuliahEditModal<?php echo $key->matakuliah_id ?>">
                    <span class="text">
                      <i class="fa fa-edit"></i>
                    </span>
                  </a>
                  <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#matakuliahRemoveModal<?php echo $key->matakuliah_id ?>">
                    <span class="text">
                      <i class="fa fa-trash"></i>
                    </span>
                  </a>

                </td>
                <td><?php echo $key->matakuliah_id ?></td>
                <td><?php echo $key->matakuliah_nama ?></td>
                <td><?php echo $key->matakuliah_sks ?></td>
                <td><?php echo $key->matakuliah_semester ?></td>
              </tr>

              <!-- Looping Modal Area -->



              <div class="modal fade" id="matakuliahEditModal<?php echo $key->matakuliah_id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Edit matakuliah</h5>
                      <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                    <?php echo form_open_multipart("matakuliah/edit") ?>
                    <div class="modal-body">
                      <div class="form-group">
                        <label for=""><b>Nim matakuliah</b></label>
                        <input type="text" class="form-control" name="matakuliah_id" required="required" value="<?php echo $key->matakuliah_id ?>">
                      </div>
                      <div class="form-group">
                        <label for=""><b>Nama matakuliah</b></label>
                        <input type="text" class="form-control" name="matakuliah_nama" required="required" value="<?php echo $key->matakuliah_nama ?>">
                      </div>
                      <div class="form-group">
                        <label for=""><b>SKS</b></label>
                        <input type="text" class="form-control" name="matakuliah_sks" required="required" value="<?php echo $key->matakuliah_sks ?>">
                      </div>
                      <div class="form-group">
                        <label for=""><b>Semester</b></label>
                        <input type="text" class="form-control" name="matakuliah_semester" required="required" value="<?php echo $key->matakuliah_semester ?>">
                      </div>
                    </div>

                    <div class="modal-footer">
                      <button class="btn btn-warning" type="submit">Edit</button>
                      <?php echo form_close(); ?>
                      <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>

                    </div>
                  </div>
                </div>
              </div>
              <!-- matakuliah Modal Remove-->
              <div class="modal fade" id="matakuliahRemoveModal<?php echo $key->matakuliah_id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Hapus matakuliah</h5>
                      <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                    <?php echo form_open("matakuliah/delete") ?>
                    <div class="modal-body">
                      Apakah anda yakin akan menghapus data matakuliah <b><?php echo $key->matakuliah_nama ?></b> ?
                      <input type="hidden" class="form-control" name="matakuliah_id" value="<?php echo $key->matakuliah_id ?>">
                    </div>
                    <div class="modal-footer">
                      <button class="btn btn-danger" type="submit">Hapus</button>
                      <?php echo form_close(); ?>
                      <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>

                    </div>
                  </div>
                </div>
              </div>

              <!-- End Looping -->


            <?php $no++;
            } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->