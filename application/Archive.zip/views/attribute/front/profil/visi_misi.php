  <section class="ftco-section">
      <div class="container">
        
          
          <h1>VISI</h1>
          “Dinas Lingkungan Hidup dan Kehutanan Kota Kendari bertugas membantu Walikota melaksanakan urusan pemerintahan yang menjadi kewenangan daerah dan tugas pembantuan di bidang lingkungan hidup dan bidang kehutanan.”

          <br><br><br>
          
          <h1>MISI</h1>
          Dinas Lingkungan Hidup dan Kehutanan Kota Kendari menyelenggarakan fungsi :<br>
          <ol>
            <li>Pelaksanaan kegiatan penyusunan program kerja dan rencana anggaran Dinas;</li>
            <li>Penyusunan petunjuk teknis pelaksanaan kegiatan penyelenggaraan Dinas</li>
            <li>Pelaksanaan kegiatan pembinaan, pengawasan, dan pengendalian tugas Sekretaris dan Kepala Bidang;</li>
            <li>Pelaksanaan kegiatan pengkoordinasian pelaksanaan tugas dengan instansi terkait;</li>
            <li>Pelaksanaan perumusan pedoman, petunjuk teknis kebijakan dan pembinaan lingkungan hidup dan kehutanan;</li>
            <li>Pelaksanaan pengawasan dan pengendalian manfaat lingkungan hidup dan kehutanan;</li>
            <li>Pelaksanaan pembinaan pengembangan lingkungan hidup dan kehutanan;</li>
            <li>Pelaksanaan konservasi tanah dan air;</li>
            <li>Pelaksanaan pengawasan dan pengendalian penghijauan dan reboisasi;</li>
            <li>Pelaksanaan perlindungan dan pengamanan lingkungan hidup dan kehutanan;</li>
            <li>Pelaksanaan dan pengawasan dan bimbingan teknis terhadap unit pelaksana teknis, kepegawaian, keuangan, perencanaan serta evaluasi dan pelaporan; dan</li>
            <li>Pelaksanaan fungsi lain yang diberikan oleh Walikota sesuai dengan tugas dan fungsi Dinas.</li>
          </ol>
          

          

          
          
          
        
        
      </div>
    </section>