  <section class="ftco-section bg-light">
      <div class="container">
        
          
         <img src="<?php echo base_url()?>upload/news/<?php echo $berita[0]->news_picture?>"><br>
         <h2><?php echo $berita[0]->news_title?></h2>
         <b><?php echo $berita[0]->news_date?></b>
         <br>
         <?php echo $berita[0]->news_text?>
          
          
        </div>
        
        
      </div>
    </section>